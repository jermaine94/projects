public class VideoSet {
    public int id { get; set; }
    public List<Video> results { get; set; }
}
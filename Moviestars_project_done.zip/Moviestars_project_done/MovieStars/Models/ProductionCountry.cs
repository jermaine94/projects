public class ProductionCountry {
    public string iso_3166_1 { get; set; }
    public string name { get; set; }
}
public class SpokenLanguage {
    public string english_name { get; set; }
    public string iso_639_1 { get; set; }
    public string name { get; set; }
}
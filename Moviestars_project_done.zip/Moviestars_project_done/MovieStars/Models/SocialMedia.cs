public class SocialMedia
    {
        public int id { get; set; }
        
        public string? imdb_id { get; set; }
        
        public string? facebook_id { get; set; }
        public string? instagram_id { get; set; }
        
        public string? twitter_id { get; set; }
       
    }
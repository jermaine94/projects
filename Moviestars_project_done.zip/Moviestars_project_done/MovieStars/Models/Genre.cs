public class Genre {
    public int id { get; set; }
    public string name { get; set; }
}
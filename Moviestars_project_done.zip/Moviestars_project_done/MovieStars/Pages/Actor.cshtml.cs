
using Microsoft.AspNetCore.Mvc.RazorPages;
using MovieStars.API;

namespace MovieStars.Pages;

public class ActorModel : PageModel {

    public string poster_path = "https://image.tmdb.org/t/p/w500";
    public string image_path = "https://image.tmdb.org/t/p/w500";
    public string bio = "";
    public string name = "";
    public string dob = "";
    public string placeofbirth = "";
    public string  instagram = "";
    public string  facebook = "";
    public string  twitter = "";
    public  int Actorage = 0;
    public List<string> crewIMGs = new List<string>();
    public async Task OnGet(string actorID) {
      await Fetch.GetActorDetails(actorID);  
      bio = Fetch.actor.biography;
      dob = Fetch.actor.birthday;
      if(dob != null){
        string dobYear = dob.Substring(0, 4);
      int dobYearInt = Int32.Parse(dobYear);
      int todayYear = DateTime.Now.Year;
      Actorage = todayYear - dobYearInt;
      }
      name = Fetch.actor.name;
      placeofbirth = Fetch.actor.place_of_birth;
      poster_path += poster_path + Fetch.actor.profile_path;
      await Fetch.GetActorHome(actorID);
      int MAX_image = Fetch.imageSet.profiles.Count;
      for(int i = 0; i < MAX_image; i++) {
            if(Fetch.imageSet.profiles[i].file_path != null) {
                crewIMGs.Add(image_path + Fetch.imageSet.profiles[i].file_path);
            }
            else {
                crewIMGs.Add("./images/default_profile_pic.jpg");
            }
      await Fetch.GetSocialMedia(actorID);
      instagram = Fetch.socialMedia.instagram_id;
      facebook = Fetch.socialMedia.facebook_id;
      twitter = Fetch.socialMedia.twitter_id;
    }
    
}   
}
   